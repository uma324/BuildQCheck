package com.example.bqc

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bqc.databinding.ActivitySignInBinding
import com.google.firebase.auth.FirebaseAuth

class SignIn : AppCompatActivity() {
    private lateinit var binding: ActivitySignInBinding
    private lateinit var firebaseAuth : FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        firebaseAuth =  FirebaseAuth.getInstance()

        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvForgotPassword.setOnClickListener{
            val i = Intent(this,ForgotPassword::class.java)
            startActivity(i)
        }
        binding.btnSignin.setOnClickListener{
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()
            if(email.isNotEmpty() && password.isNotEmpty()){
                firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener{
                    if(it.isSuccessful){
                        val user=firebaseAuth.currentUser
                        if(user!=null) {
                            if (user.isEmailVerified) {
                                val i = Intent(this, MainActivity::class.java)
                                startActivity(i)
                            } else {
                                Toast.makeText(
                                    this,
                                    "Your email is not verified. Check your mail for verification link",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                    else{
                        Toast.makeText(this,it.exception.toString(), Toast.LENGTH_SHORT).show()
                    }
                }
            }
            else{
                Toast.makeText(this,"One or more fields is empty.", Toast.LENGTH_SHORT).show()
            }
        }


        binding.tvSignup.setOnClickListener{
            val i = Intent(this,SignUp::class.java)
            startActivity(i)
        }
    }
}