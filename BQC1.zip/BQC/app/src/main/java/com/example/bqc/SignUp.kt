package com.example.bqc

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bqc.databinding.ActivitySignUpBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.userProfileChangeRequest

class SignUp : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding
    private lateinit var firebaseAuth : FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        firebaseAuth = FirebaseAuth.getInstance()

        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSignup.setOnClickListener{
            val name = binding.etFullname.text.toString()
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()
            val confPass = binding.etConfirmPassword.text.toString()

            if (name.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty() && confPass.isNotEmpty()){
                if (password == confPass){
                    firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener{
                        if(it.isSuccessful){
                            val profileUpdates = userProfileChangeRequest {
                                displayName = name
                            }
                            firebaseAuth.currentUser?.updateProfile(profileUpdates)
                            val user = firebaseAuth.currentUser
                            user?.sendEmailVerification()?.addOnCompleteListener{
                                firebaseAuth.signOut()
                                if(it.isSuccessful){
                                    Toast.makeText(this,"Check your mail for verification link.", Toast.LENGTH_LONG).show()
                                }
                                else{
                                    Toast.makeText(this,it.exception.toString(), Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        else{
                            Toast.makeText(this,"${it.exception.toString()}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                else{
                    Toast.makeText(this,"Passwords do not match.", Toast.LENGTH_SHORT).show()
                }
            }
            else{
                Toast.makeText(this,"One or more field is empty.", Toast.LENGTH_SHORT).show()
            }
        }




        binding.tvBackToSignin.setOnClickListener{
            val i = Intent(this,SignIn::class.java)
            startActivity(i)
        }

    }

    override fun onStart() {
        super.onStart()
        firebaseAuth = FirebaseAuth.getInstance()
        val user = firebaseAuth.currentUser
        if(user!=null && user.isEmailVerified){
            val i = Intent(this,MainActivity::class.java)
            startActivity(i)
        }
    }
}