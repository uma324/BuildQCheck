package com.example.bqc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class ConstructionSite(
    val name: String,
    val status: String
)

class SiteAdapter(private val siteList: List<ConstructionSite>) :
    RecyclerView.Adapter<SiteAdapter.SiteViewHolder>() {

    class SiteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val siteName: TextView = itemView.findViewById(R.id.textViewSiteName)
        val siteStatus: TextView = itemView.findViewById(R.id.textViewStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SiteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_site_card, parent, false)
        return SiteViewHolder(view)
    }

    override fun onBindViewHolder(holder: SiteViewHolder, position: Int) {
        val site = siteList[position]
        holder.siteName.text = site.name
        holder.siteStatus.text = "Status: ${site.status}"
    }

    override fun getItemCount(): Int = siteList.size
}


class SiteList : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: SiteAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_site_list)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val siteList = listOf(
            ConstructionSite("Downtown Mall", "Active"),
            ConstructionSite("Bridge Expansion", "Paused"),
            ConstructionSite("New Apartment Block", "Active")
        )
        adapter = SiteAdapter(siteList)
        recyclerView.adapter = adapter
    }
}