package com.example.bqc

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContentView(R.layout.activity_main)
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.navigationmenu)

        bottomNavigation.setOnNavigationItemSelectedListener {
            menuitem->
            when(menuitem.itemId){
                R.id.home->{
                    loadFragment(homefragment())
                    true
                }
                R.id.search->{
                    loadFragment(searchfragment())
                    true
                }
                R.id.profile->{
                    loadFragment(profilefragment())
                    true
                }
                else->false
            }
        }
        loadFragment(homefragment())

    }
    private fun loadFragment(fragment: Fragment){
        val fragManager : androidx.fragment.app.FragmentManager = supportFragmentManager
        val change : androidx.fragment.app.FragmentTransaction = fragManager.beginTransaction()
        change.replace(R.id.DynamicFragment ,fragment)
        change.commit()
    }
}