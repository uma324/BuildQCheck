package com.example.bqc

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import kotlin.math.sign

class profilefragment: Fragment() {
    private lateinit var firebaseAuth: FirebaseAuth
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        firebaseAuth = FirebaseAuth.getInstance()
        val view = inflater.inflate(R.layout.profilefragment,container,false)
        view.findViewById<TextView>(R.id.profile_email).text = firebaseAuth.currentUser?.email.toString()
        val aboutApp = view.findViewById<Button>(R.id.btn_app_info)
        val profileName = view.findViewById<TextView>(R.id.profile_name)
        firebaseAuth.currentUser?.let {
            profileName.text = it.displayName.toString()
        }


        aboutApp.setOnClickListener {
            val intent = Intent(requireContext(), AboutScreen::class.java)
            startActivity(intent)
        }

        val signOut = view.findViewById<Button>(R.id.btn_sign_out)
        signOut.setOnClickListener {
            firebaseAuth.signOut()
            val intent = Intent(requireContext(), SignIn::class.java)
            startActivity(intent)
            requireActivity().finish()
        }

        val user = FirebaseAuth.getInstance().currentUser
        val deleteAccount = view.findViewById<Button>(R.id.btn_delete_account)
        deleteAccount.setOnClickListener {
            user?.delete()?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Account deleted successfully
                    val intent = Intent(requireContext(), SignUp::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    requireActivity().finish()
                } else {
                    // Deletion failed (maybe the user needs to re-authenticate)
                    val error = task.exception?.message ?: "Account deletion failed."
                    Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show()
                }
            }
        }

        return view
    }
}