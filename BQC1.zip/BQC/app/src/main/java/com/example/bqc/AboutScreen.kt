package com.example.bqc

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bqc.databinding.ActivityAboutScreenBinding

class AboutScreen : AppCompatActivity() {
    private lateinit var binding: ActivityAboutScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "" // Hides default title if you're using the custom TextView inside the Toolbar

        // Set version dynamically (optional)
        val versionName = packageManager.getPackageInfo(packageName, 0).versionName
        binding.txtVersion.text = "Version $versionName"
    }

    // Called from XML onClick attribute
    fun openPrivacyPolicy(view: View) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.constructiontech.com/privacy"))
        startActivity(intent)
    }

    // Called from XML onClick attribute
    fun openTermsOfService(view: View) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.constructiontech.com/terms"))
        startActivity(intent)
    }

    // Optional: Handle back button in toolbar
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}